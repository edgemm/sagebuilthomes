<?php 
/**
* Plugin Name: Build Theme Functionality
* Plugin URI: http://jellythemes.com
* Description: Required plugin, Build WordPress Theme functionality: Shortcodes, custom posts types, taxonomies, etc.
* Version: 1.1.0
* Author: Jellythemes
* Author URI: http://jellythemes.com
* License: GPL2
*/
	/* POSTS TYPES DEFINITION FUNCTIONS */
    include plugin_dir_path( __FILE__ ) . '/functions.posts_types.php';
	/* SHORTCODES DEFINITION */
    include plugin_dir_path( __FILE__ ) . '/functions.shortcodes.php';
    /* METABOXES FRAMEWORK LOAD */
    require_once plugin_dir_path( __FILE__ ) . '/meta-box/meta-box.php';
    include plugin_dir_path( __FILE__ ) . '/functions.meta-boxes.php';

    add_action( 'plugins_loaded', 'build_jellythemes_plugin_textdomain' );
	function build_jellythemes_plugin_textdomain() {
	  load_plugin_textdomain( 'build-jellythemes', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' ); 
	}
?>