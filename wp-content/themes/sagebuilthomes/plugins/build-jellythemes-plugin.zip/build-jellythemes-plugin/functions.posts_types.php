<?php
/* POSTS TYPES DEFINITION */


add_action('init', 'build_jellythemes_testimonials');
add_action('init', 'build_jellythemes_works');


function build_jellythemes_testimonials()  {
  $labels = array(
    'name' => esc_html__('Testimonials', 'framework'),
    'singular_name' => esc_html__('Testimonial', 'framework'),
    'add_new' => esc_html__('Add Testimonial', 'framework'),
    'add_new_item' => esc_html__('Add Testimonial', 'framework'),
    'edit_item' => esc_html__('Edit Testimonial', 'framework'),
    'new_item' => esc_html__('New Testimonials', 'framework'),
    'view_item' => esc_html__('View Testimonial', 'framework'),
    'search_items' => esc_html__('Search Testimonials', 'framework'),
    'not_found' =>  esc_html__('No Testimonials found', 'framework'),
    'not_found_in_trash' => esc_html__('No Testimonials found in Trash', 'framework'),
    'parent_item_colon' => ''
  );

  $args = array(
    'labels' => $labels,
    'public' => true,
    'publicly_queryable' => true,
    'show_ui' => true,
    'query_var' => true,
    'capability_type' => 'post',
    'show_in_nav_menus' => false,
    'hierarchical' => false,
    'exclude_from_search' => true,
    'menu_position' => 5,
    'supports' => array('title')
  );
  register_post_type('testimonials',$args);
}


function build_jellythemes_works()  {
  $labels = array(
    'name' => esc_html__('Works', 'framework'),
    'singular_name' => esc_html__('Work', 'framework'),
    'add_new' => esc_html__('Add Work', 'framework'),
    'add_new_item' => esc_html__('Add Work', 'framework'),
    'edit_item' => esc_html__('Edit Work', 'framework'),
    'new_item' => esc_html__('New Work', 'framework'),
    'view_item' => esc_html__('View Works', 'framework'),
    'search_items' => esc_html__('Search Works', 'framework'),
    'not_found' =>  esc_html__('No Works found', 'framework'),
    'not_found_in_trash' => esc_html__('No Works found in Trash', 'framework'),
    'parent_item_colon' => ''
  );

  $args = array(
    'labels' => $labels,
    'public' => true,
    'publicly_queryable' => true,
    'show_ui' => true,
    'query_var' => true,
    'capability_type' => 'post',
    'show_in_nav_menus' => false,
    'hierarchical' => false,
    'exclude_from_search' => true,
    'menu_position' => 5,
    'rewrite' => array( 'slug' => 'work' ),
    'taxonomies' => array('type'),
    'supports' => array('title','thumbnail')
  );
  register_post_type('works',$args);
}

function work_type() {
    register_taxonomy("type",
    array("work"),
    array(
        "hierarchical" => true,
        "label" => esc_html__( "Type", 'framework'),
        "singular_label" => esc_html__( "Type", 'framework'),
        "rewrite" => array( 'slug' => 'type', 'hierarchical' => true),
        'show_in_nav_menus' => false,
        )
    );
}

add_action( 'init', 'Work_type', 0);

?>
