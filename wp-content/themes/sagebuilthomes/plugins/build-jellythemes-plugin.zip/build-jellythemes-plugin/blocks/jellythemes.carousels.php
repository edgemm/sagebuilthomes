<?php
$animations = array('bounce' => 'bounce',
	'flash' => 'flash',
	'pulse' => 'pulse',
	'rubberBand' => 'rubberBand',
	'shake' => 'shake',
	'swing' => 'swing',
	'tada' => 'tada',
	'wobble' => 'wobble',
	'jello' => 'jello',
	'bounceIn' => 'bounceIn',
	'bounceInDown' => 'bounceInDown',
	'bounceInLeft' => 'bounceInLeft',
	'bounceInRight' => 'bounceInRight',
	'bounceInUp' => 'bounceInUp',
	'bounceOut' => 'bounceOut',
	'bounceOutDown' => 'bounceOutDown',
	'bounceOutLeft' => 'bounceOutLeft',
	'bounceOutRight' => 'bounceOutRight',
	'bounceOutUp' => 'bounceOutUp',
	'fadeIn' => 'fadeIn',
	'fadeInDown' => 'fadeInDown',
	'fadeInDownBig' => 'fadeInDownBig',
	'fadeInLeft' => 'fadeInLeft',
	'fadeInLeftBig' => 'fadeInLeftBig',
	'fadeInRight' => 'fadeInRight',
	'fadeInRightBig' => 'fadeInRightBig',
	'fadeInUp' => 'fadeInUp',
	'fadeInUpBig' => 'fadeInUpBig',
	'fadeOut' => 'fadeOut',
	'fadeOutDown' => 'fadeOutDown',
	'fadeOutDownBig' => 'fadeOutDownBig',
	'fadeOutLeft' => 'fadeOutLeft',
	'fadeOutLeftBig' => 'fadeOutLeftBig',
	'fadeOutRight' => 'fadeOutRight',
	'fadeOutRightBig' => 'fadeOutRightBig',
	'fadeOutUp' => 'fadeOutUp',
	'fadeOutUpBig' => 'fadeOutUpBig',
	'flip' => 'flip',
	'flipInX' => 'flipInX',
	'flipInY' => 'flipInY',
	'flipOutX' => 'flipOutX',
	'flipOutY' => 'flipOutY',
	'lightSpeedIn' => 'lightSpeedIn',
	'lightSpeedOut' => 'lightSpeedOut',
	'rotateIn' => 'rotateIn',
	'rotateInDownLeft' => 'rotateInDownLeft',
	'rotateInDownRight' => 'rotateInDownRight',
	'rotateInUpLeft' => 'rotateInUpLeft',
	'rotateInUpRight' => 'rotateInUpRight',
	'rotateOut' => 'rotateOut',
	'rotateOutDownLeft' => 'rotateOutDownLeft',
	'rotateOutDownRight' => 'rotateOutDownRight',
	'rotateOutUpLeft' => 'rotateOutUpLeft',
	'rotateOutUpRight' => 'rotateOutUpRight',
	'slideInUp' => 'slideInUp',
	'slideInDown' => 'slideInDown',
	'slideInLeft' => 'slideInLeft',
	'slideInRight' => 'slideInRight',
	'slideOutUp' => 'slideOutUp',
	'slideOutDown' => 'slideOutDown',
	'slideOutLeft' => 'slideOutLeft',
	'slideOutRight' => 'slideOutRight',
	'zoomIn' => 'zoomIn',
	'zoomInDown' => 'zoomInDown',
	'zoomInLeft' => 'zoomInLeft',
	'zoomInRight' => 'zoomInRight',
	'zoomInUp' => 'zoomInUp',
	'zoomOut' => 'zoomOut',
	'zoomOutDown' => 'zoomOutDown',
	'zoomOutLeft' => 'zoomOutLeft',
	'zoomOutRight' => 'zoomOutRight',
	'zoomOutUp' => 'zoomOutUp',
	'hinge' => 'hinge',
	'rollIn' => 'rollIn',
	'rollOut' => 'rollOut');
/***********************************************************
*
*	BASIC IMAGES CAROUSEL
*
***********************************************************/
function build_jellythemes_images_carousel( $atts, $content = null ) {
	extract( shortcode_atts( array(
        'images' => array(),
        'animation_in' => 'slideInLeft',
        'animation_out' => 'slideOutRight',
        'dots' => 'false',
        'nav' => 'true',
        'loop' => 'true',
        'items' => '1',
	), $atts ) );
	$return = '';
	$images_ids = explode(',',$images);

	$return = '<div class="generic-carousel" data-animation-out="'.esc_attr($animation_out).'" data-animation-in="'.esc_attr($animation_in).'" data-dots="'.esc_attr($dots).'" data-nav="'. esc_attr($nav).'" data-loop="'.esc_attr($loop).'" data-items="'.esc_attr($items).'">';
        	foreach ($images_ids as $id) {
	        	$return .=  '<div class="item">' . wp_get_attachment_image($id, 'full')  .  '</div>';
	        }
    $return .= '</div>';
    
    return $return;
}
add_shortcode( 'build_jellythemes_images_carousel', 'build_jellythemes_images_carousel' );

if (function_exists('vc_map')) {
	
	vc_map( array(
	    "name" => esc_html__("Image Carousel", "jellythemes"),
	    "base" => "build_jellythemes_images_carousel",
	    "icon" => "icon-wpb-images-carousel",
	    "category" => esc_html__('Jellythemes', 'build-jellythemes'),
	    "description" => esc_html__('Animated carousel with images', 'build-jellythemes'),
	    "params" => array(
		        array(
		            "type" => "attach_images",
		            "heading" => esc_html__("Images", "jellythemes"),
		            "param_name" => "images",
		            "value" => "",
		            "description" => esc_html__("Select images from media library.", "jellythemes")
		        ),
		        array(
			      "type" => "dropdown",
			      "heading" => esc_html__('Dots', 'build-jellythemes'),
			      "param_name" => "dots",
			      "value" => array(
	                        esc_html__("No", 'build-jellythemes') => 'false',
	                        esc_html__("Yes", 'build-jellythemes') => 'true',
	                      ),
    		),
	    	array(
			      "type" => "dropdown",
			      "heading" => esc_html__('Nav', 'build-jellythemes'),
			      "param_name" => "nav",
			      "value" => array(
	                        esc_html__("No", 'build-jellythemes') => 'false',
	                        esc_html__("Yes", 'build-jellythemes') => 'true',
	                      ),
    		),
			array(
			      "type" => "dropdown",
			      "heading" => esc_html__('Loop', 'build-jellythemes'),
			      "param_name" => "loop",
			      "value" => array(
	                        esc_html__("No", 'build-jellythemes') => 'false',
	                        esc_html__("Yes", 'build-jellythemes') => 'true',
	                      ),
    		),
			array(
			      "type" => "dropdown",
			      "heading" => esc_html__('Items', 'build-jellythemes'),
			      "param_name" => "items",
			      "value" => array(
	                        esc_html__("1", 'build-jellythemes') => '1',
	                        esc_html__("2", 'build-jellythemes') => '2',
	                        esc_html__("3", 'build-jellythemes') => '3',
	                        esc_html__("4", 'build-jellythemes') => '4',
	                      ),
    		),
			array(
			      "type" => "dropdown",
			      "heading" => esc_html__('Animation In', 'build-jellythemes'),
			      "param_name" => "animation_in",
			      "value" => $animations,
			      "std" => 'slideInLeft'
    		),
			array(
			      "type" => "dropdown",
			      "heading" => esc_html__('Animation Out', 'build-jellythemes'),
			      "param_name" => "animation_out",
			      "value" => $animations,
			      "std" => 'slideOutRight'
    		)
		    ),
	    
	) );
}


/***********************************************************
*
*	ADVANCED SLIDER
*
***********************************************************/
function build_jellythemes_slider( $atts, $content = null ) {
	extract( shortcode_atts( array(
        'animation_in' => 'slideOutRight',
        'animation_out' => 'slideInLeft',
        'dots' => 'false',
        'nav' => 'true',
        'loop' => 'true',
        'items' => '1',
	), $atts ) );
	$content = wpb_js_remove_wpautop($content, true);
    $return = '<div class="carousel-wrap">
        <div class="generic-carousel" data-animation-out="'.esc_attr($animation_out).'" data-animation-in="'.esc_attr($animation_in).'" data-dots="'.esc_attr($dots).'" data-nav="'. esc_attr($nav).'" data-loop="'.esc_attr($loop).'" data-items="'.esc_attr($items).'">
                '. do_shortcode($content) .'
        </div>
    </div>';
    return $return;
}
add_shortcode( 'build_jellythemes_slider', 'build_jellythemes_slider' );

function build_jellythemes_slide_item( $atts, $content = null ) {
	extract( shortcode_atts( array(
        'title' => esc_html__("welcome to build", 'build-jellythemes'),
        'text_content' => esc_html__("look at the information and look at the information andsed diam nonumy eirmod roedtem por in vid unt ut labore magnaadi piocar semper mani laoreet adipisicing", 'build-jellythemes'),
        'button' => esc_html__("LEARN MORE", 'build-jellythemes'),
        'button_link' => site_url(),
        'image' => '',
	), $atts ) );
    $return = '<div class="item">
                    ' . wp_get_attachment_image($image, 'full')  .  '
                    <div class="slide-content">
                        <div class="vertical-align">
                            <h2 class="title light fz40">' . esc_html($title) . '</h2>
                            <h3 class="subtitle light fz18">' . esc_html($text_content) . '</h3>
                            <a href="' . esc_url($button_link) . '" class="button">' . esc_html($button) . '</a>
                        </div>
                    </div>
                </div>';
    return $return;
}
add_shortcode( 'build_jellythemes_slide_item', 'build_jellythemes_slide_item' );

if (function_exists('vc_map')) {
	

	vc_map( array(
	    "name" => esc_html__("Slider (BG+Text+Button)", "jellythemes"),
	    "base" => "build_jellythemes_slider",
	    "content_element" => true,
	    "as_parent" => array('only' => 'build_jellythemes_slide_item'),
	   	"category" => esc_html__('Jellythemes', 'build-jellythemes'),
	    "show_settings_on_create" => true,
	    "is_container" => true,
	    "params" => array(
	    	array(
			      "type" => "dropdown",
			      "heading" => esc_html__('Dots', 'build-jellythemes'),
			      "param_name" => "dots",
			      "value" => array(
	                        esc_html__("No", 'build-jellythemes') => 'false',
	                        esc_html__("Yes", 'build-jellythemes') => 'true',
	                      ),
    		),
	    	array(
			      "type" => "dropdown",
			      "heading" => esc_html__('Nav', 'build-jellythemes'),
			      "param_name" => "nav",
			      "value" => array(
	                        esc_html__("No", 'build-jellythemes') => 'false',
	                        esc_html__("Yes", 'build-jellythemes') => 'true',
	                      ),
    		),
			array(
			      "type" => "dropdown",
			      "heading" => esc_html__('Loop', 'build-jellythemes'),
			      "param_name" => "loop",
			      "value" => array(
	                        esc_html__("No", 'build-jellythemes') => 'false',
	                        esc_html__("Yes", 'build-jellythemes') => 'true',
	                      ),
    		),
			array(
			      "type" => "dropdown",
			      "heading" => esc_html__('Items', 'build-jellythemes'),
			      "param_name" => "items",
			      "value" => array(
	                        esc_html__("1", 'build-jellythemes') => '1',
	                        esc_html__("2", 'build-jellythemes') => '2',
	                        esc_html__("3", 'build-jellythemes') => '3',
	                        esc_html__("4", 'build-jellythemes') => '4',
	                      ),
    		),
			array(
			      "type" => "dropdown",
			      "heading" => esc_html__('Animation In', 'build-jellythemes'),
			      "param_name" => "animation_in",
			      "value" => $animations,
    		),
			array(
			      "type" => "dropdown",
			      "heading" => esc_html__('Animation Out', 'build-jellythemes'),
			      "param_name" => "animation_out",
			      "value" => $animations,
    		)
		),
	    "js_view" => 'VcColumnView'
	) );


	vc_map( array(
	   "name" => esc_html__("Slide Item", 'build-jellythemes'),
	   "base" => "build_jellythemes_slide_item",
	   "class" => "",
	   "icon" => "jelly-icon",
	   "category" => esc_html__('Jellythemes', 'build-jellythemes'),
	   "as_child" => array('only' => 'build_jellythemes_slider'),
	   "params" => array(
	   		array(
	            "type" => "attach_image",
	            "heading" => esc_html__("Background image", "jellythemes"),
	            "param_name" => "image",
	            "value" => "",
	            "description" => esc_html__("Select image from media library.", "jellythemes")
	        ),
	        array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Title", 'build-jellythemes'),
				"param_name" => "title",
				"value" => esc_html__("welcome to build", 'build-jellythemes'),
			),
			array(
				"type" => "textarea",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Text content", 'build-jellythemes'),
				"param_name" => "text_content",
				"value" => esc_html__("look at the information and look at the information andsed diam nonumy eirmod roedtem por in vid unt ut labore magnaadi piocar semper mani laoreet adipisicing", 'build-jellythemes'),
			),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Button text", 'build-jellythemes'),
				"param_name" => "button",
				"value" => esc_html__("LEARN MORE", 'build-jellythemes'),
			),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Button link", 'build-jellythemes'),
				"param_name" => "button_link",
				"value" => site_url(),
			),
	   	)
	));
}


//Your "container" content element should extend WPBakeryShortCodesContainer class to inherit all required functionality
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_build_jellythemes_slider extends WPBakeryShortCodesContainer {
    }
    class WPBakeryShortCode_build_jellythemes_slide_item extends WPBakeryShortCode {
    }
}


/***********************************************************
*
*	TESTIMONIAL SLIDER
*
***********************************************************/
function build_jellythemes_services_slider( $atts, $content = null ) {
	$content = wpb_js_remove_wpautop($content, true);
    return '<div class="services-carousel clearfix">'. do_shortcode($content) .'</div>';
}
add_shortcode( 'build_jellythemes_services_slider', 'build_jellythemes_services_slider' );

function build_jellythemes_service_slide_item( $atts, $content = null ) {
	extract( shortcode_atts( array(
        'title' => esc_html__("Architecture", 'build-jellythemes'),
        'text_content' => esc_html__("Through workshops you'll have the opportunity to ssee how small", 'build-jellythemes'),
        'icon' => 'icon-home',
	), $atts ) );
	return '<div class="col-sm-3 service">
                    <i class="icon ' . esc_attr($icon) . '"></i>
                    <h3 class="name">' . esc_html($title) . '</h3>
                    <p>' . esc_html($text_content) . '</p>
                </div>';
}
add_shortcode( 'build_jellythemes_service_slide_item', 'build_jellythemes_service_slide_item' );

if (function_exists('vc_map')) {
	

	vc_map( array(
	    "name" => esc_html__("Services slider", "jellythemes"),
	    "base" => "build_jellythemes_services_slider",
	    "content_element" => true,
	    "as_parent" => array('only' => 'build_jellythemes_service_slide_item'),
	   	"category" => esc_html__('Jellythemes', 'build-jellythemes'),
	    "show_settings_on_create" => false,
	    "is_container" => true,
	    "params" => array(),
	    "js_view" => 'VcColumnView'
	) );

	global $build_jellythemes_fonticons;
	vc_map( array(
	   "name" => esc_html__("Service Slide", 'build-jellythemes'),
	   "base" => "build_jellythemes_service_slide_item",
	   "class" => "",
	   "icon" => "jelly-icon",
	   "category" => esc_html__('Jellythemes', 'build-jellythemes'),
	   "as_child" => array('only' => 'build_jellythemes_serivces_slider'),
	   "params" => array(
	   		array(
				"type" => "dropdown",
				"heading" => esc_html__('Icon', 'build-jellythemes'),
				"param_name" => "icon",
				"value" => $build_jellythemes_fonticons,
			),
	        array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Title", 'build-jellythemes'),
				"param_name" => "title",
				"value" => esc_html__("Architecture", 'build-jellythemes'),
			),
			array(
				"type" => "textarea",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Text content", 'build-jellythemes'),
				"param_name" => "text_content",
				"value" => esc_html__("Through workshops you'll have the opportunity to ssee how small", 'build-jellythemes'),
			),
	   	)
	));
}


//Your "container" content element should extend WPBakeryShortCodesContainer class to inherit all required functionality
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_build_jellythemes_services_slider extends WPBakeryShortCodesContainer {
    }
    class WPBakeryShortCode_build_jellythemes_service_slide_item extends WPBakeryShortCode {
    }
}

/***********************************************************
*
*	TESTIMONIALS SLIDER
*
***********************************************************/
function build_jellythemes_testimonials_slider( $atts, $content = null ) {
	$content = wpb_js_remove_wpautop($content, true);
    return '<div id="owl-testimonials" class="generic-carousel" data-animation-out="fadeOut" data-animation-in="fadeIn" data-dots="true" data-nav="false">'. do_shortcode($content) .'</div>';
}
add_shortcode( 'build_jellythemes_testimonials_slider', 'build_jellythemes_testimonials_slider' );

function build_jellythemes_testimonial_slide_item( $atts, $content = null ) {
	extract( shortcode_atts( array(
        'title' => esc_html__("Sarah O'Connor, Metal & CO", 'build-jellythemes'),
        'text_content' => esc_html__("Nulla cursus commodo risus, quis consectetur risus commodo fringilla. Lorem ipsum dolor. quis consectetur risus commodo fringilla. Fusce sapien urna.", 'build-jellythemes'),
	), $atts ) );
	return '<div class="item testimonial text-center">
                <h3 class="testimonial-text">' . esc_html($text_content) . '</h3>
                <h2 class="testimonial-author">' . esc_html($title) . '</h2>
            </div>';
}
add_shortcode( 'build_jellythemes_testimonial_slide_item', 'build_jellythemes_testimonial_slide_item' );

if (function_exists('vc_map')) {
	

	vc_map( array(
	    "name" => esc_html__("Testimonials slider", "jellythemes"),
	    "base" => "build_jellythemes_testimonials_slider",
	    "content_element" => true,
	    "as_parent" => array('only' => 'build_jellythemes_testimonial_slide_item'),
	   	"category" => esc_html__('Jellythemes', 'build-jellythemes'),
	    "show_settings_on_create" => false,
	    "is_container" => true,
	    "params" => array(),
	    "js_view" => 'VcColumnView'
	) );

	global $build_jellythemes_fonticons;
	vc_map( array(
	   "name" => esc_html__("Testimonial", 'build-jellythemes'),
	   "base" => "build_jellythemes_testimonial_slide_item",
	   "class" => "",
	   "icon" => "jelly-icon",
	   "category" => esc_html__('Jellythemes', 'build-jellythemes'),
	   "as_child" => array('only' => 'build_jellythemes_serivces_slider'),
	   "params" => array(
	        array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Testimonial author", 'build-jellythemes'),
				"param_name" => "title",
				"value" => esc_html__("Sarah O'Connor, Metal & CO", 'build-jellythemes'),
			),
			array(
				"type" => "textarea",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Testimonial cite", 'build-jellythemes'),
				"param_name" => "text_content",
				"value" => esc_html__("Nulla cursus commodo risus, quis consectetur risus commodo fringilla. Lorem ipsum dolor. quis consectetur risus commodo fringilla. Fusce sapien urna.", 'build-jellythemes'),
			),
	   	)
	));
}


//Your "container" content element should extend WPBakeryShortCodesContainer class to inherit all required functionality
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_build_jellythemes_testimonials_slider extends WPBakeryShortCodesContainer {
    }
    class WPBakeryShortCode_build_jellythemes_testimonial_slide_item extends WPBakeryShortCode {
    }
}

