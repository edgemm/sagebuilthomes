<?php
/***********************************************************
*
*	GOOGLE MAP
*
***********************************************************/

function build_jellythemes_map( $atts, $content = null ) {
	extract( shortcode_atts( array(
        'lat' => "40.6700",
        'lon' => "-73.9400",
        'title' => esc_html__("BUILD Co.", 'build-jellythemes')
	), $atts ) );
	return '<div id="map-container" class="map-wrapper" data-lat="' . esc_attr($lat) . '" data-lon="' . esc_attr($lon) . '" data-title="' . esc_attr($title) . '"></div>';
}
add_shortcode( 'build_jellythemes_map', 'build_jellythemes_map' );



if (function_exists('vc_map')) {
	vc_map( array(
	   "name" => esc_html__("Map", 'build-jellythemes'),
	   "base" => "build_jellythemes_map",
	   "class" => "",
	   "icon" => "jelly-icon",
	   "category" => esc_html__('Jellythemes', 'build-jellythemes'),
	   "params" => array(
	   		array(
	            "type" => "textfield",
	            "heading" => esc_html__("Latitude", "jellythemes"),
	            "param_name" => "lat",
	            "value" => "40.6700",
	        ),
	        array(
	            "type" => "textfield",
	            "heading" => esc_html__("Longitude", "jellythemes"),
	            "param_name" => "lon",
	            "value" => "-73.9400",
	        ),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Title", 'build-jellythemes'),
				"param_name" => "title",
				"value" => esc_html__("BUILD Co.", 'build-jellythemes'),
			),
	   )
	));
}


?>