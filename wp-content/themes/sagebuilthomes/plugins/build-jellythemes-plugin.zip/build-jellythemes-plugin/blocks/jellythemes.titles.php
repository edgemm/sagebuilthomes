<?php
/***********************************************************
*
*	BASIC TITLE BLOCK
*
***********************************************************/

function build_jellythemes_title( $atts, $content = null ) {
	extract( shortcode_atts( array(
        'color' => 'dark',
        'size' => '30',
        'text' => 'The title',
        'type' => '',
        'class' => '',
	), $atts ) );
	$size = 'fz' . $size;
   	return '<h2 class="title ' . esc_attr($class) . ' ' . esc_attr($type) . ' ' . esc_attr($size) . ' ' . esc_attr($color) . '">' . esc_html($text) . '</h2>';
}
add_shortcode( 'build_jellythemes_title', 'build_jellythemes_title' );
if (function_exists('vc_map')) {
	global $build_jellythemes_fontsizes;
	vc_map( array(
	   "name" => esc_html__("Title", 'build-jellythemes'),
	   "base" => "build_jellythemes_title",
	   "class" => "",
	   "icon" => "jelly-icon",
	   "category" => esc_html__('Jellythemes', 'build-jellythemes'),
	   "params" => array(
	      	array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Title", 'build-jellythemes'),
				"param_name" => "text",
				"value" => esc_html__("Your title", 'build-jellythemes'),
				"description" => esc_html__("Enter your title.", 'build-jellythemes')
	      	),
	      	array(
				"type" => "dropdown",
				"heading" => esc_html__('Type', 'build-jellythemes'),
				"param_name" => "type",
				"value" => array('Normal' => '', 'Main' => 'main', 'Post title style' => 'post'),
		    ),
	      	array(
				"type" => "dropdown",
				"heading" => esc_html__('Color', 'build-jellythemes'),
				"param_name" => "color",
				"value" => array('Dark' => 'dark', 'Light' => 'light', 'Primary color' => 'primary'),
		    ),
			array(
				"type" => "dropdown",
				"heading" => esc_html__('Size in pixels', 'build-jellythemes'),
				"param_name" => "size",
				"value" => $build_jellythemes_fontsizes,
			),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Extra CSS class", 'build-jellythemes'),
				"param_name" => "class",
				"description" => esc_html__("i.e. voffset100 text-center.", 'build-jellythemes')
	      	),
	   )
	));
}


/***********************************************************
*
*	BASIC SUBTITLE BLOCK
*
***********************************************************/

function build_jellythemes_subtitle( $atts, $content = null ) {
	extract( shortcode_atts( array(
        'color' => 'dark',
        'size' => '30',
	), $atts ) );
	$size = 'fz' . $size;
	$allowed_html = array(
	    'a' => array(
	        'href' => array(),
	        'title' => array(),
	        'target' => array()
	    ),
	    'br' => array(),
	    'em' => array(),
	    'strong' => array(),
	);
	$content = wpb_js_remove_wpautop($content, true);
   	return '<h3 class="subtitle ' . esc_attr($size) . ' ' . esc_attr($color) . '">' . wp_kses($content, $allowed_html) . '</h3>';
   
}
add_shortcode( 'build_jellythemes_subtitle', 'build_jellythemes_subtitle' );

if (function_exists('vc_map')) {
	vc_map( array(
	   "name" => esc_html__("Subtitle", 'build-jellythemes'),
	   "base" => "build_jellythemes_subtitle",
	   "class" => "",
	   "icon" => "jelly-icon",
	   "category" => esc_html__('Jellythemes', 'build-jellythemes'),
	   "params" => array(
	      	array(
				"type" => "textarea",
				"heading" => esc_html__("Text", 'build-jellythemes'),
				"param_name" => "content",
				"description" => esc_html__("Enter your title.", 'build-jellythemes')
	      	),
	      	array(
				"type" => "dropdown",
				"heading" => esc_html__('Color', 'build-jellythemes'),
				"param_name" => "color",
				"value" => array('Dark' => 'dark', 'Light' => 'light', 'Primary color' => 'primary'),
		    ),
			array(
				"type" => "dropdown",
				"heading" => esc_html__('Size in pixels', 'build-jellythemes'),
				"param_name" => "size",
				"value" => $build_jellythemes_fontsizes,
			)
	   )
	));
}


?>