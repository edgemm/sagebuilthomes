<?php
/***********************************************************
*
*	TEAM MEMBER BLOCK
*
***********************************************************/

function build_jellythemes_team_member( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'image' => '',
        'name' => 'John Doe',
        'position' => 'CEO',
        'tw_url' => '',
        'fb_url' => '',
        'gp_url' => '',
        'pi_url' => '',
        'ig_url' => '',
        'type' => 'tmb-standar'
	), $atts ) );
	$image = wp_get_attachment_image_src($image, 'full');
	$return = 	'<div class="' . esc_attr($type) . '">
                    <img src="' . $image[0] . '" alt="' . esc_attr($name) . '">
                    <div class="tmb-data">
                        <h3 class="tmb-title">' . esc_html($name) . '</h3>
                        <h4 class="tmb-position">' . esc_html($position) . '</h4>
                        <div class="tmb-links">';
    if (!empty($fb_url)) { $return .= '<a href="' . esc_url($fb_url) . '"><i class="icon fa fa-facebook"></i></a>'; }
    if (!empty($tw_url)) { $return .= '<a href="' . esc_url($tw_url) . '"><i class="icon fa fa-twitter"></i></a>'; }
    if (!empty($gp_url)) { $return .= '<a href="' . esc_url($gp_url) . '"><i class="icon fa fa-google-plus"></i></a>'; }
    if (!empty($pi_url)) { $return .= '<a href="' . esc_url($pi_url) . '"><i class="icon fa fa-pinterest"></i></a>'; }
    if (!empty($ig_url)) { $return .= '<a href="' . esc_url($ig_url) . '"><i class="icon fa fa-instagram"></i></a>'; }               
    $return .=			'</div>
                    </div>
                </div>';
   	return $return;
}
	add_shortcode( 'build_jellythemes_team_member', 'build_jellythemes_team_member' );
	vc_map( array(
	   "name" => esc_html__("Team member", 'build-jellythemes'),
	   "base" => "build_jellythemes_team_member",
	   "class" => "",
	   "icon" => "jelly-icon",
	   "category" => esc_html__('Jellythemes', 'build-jellythemes'),
	   "params" => array(
	   		array(
			      "type" => "dropdown",
			      "heading" => esc_html__('Layout type', 'build-jellythemes'),
			      "param_name" => "type",
			      "value" => array(
	                        esc_html__("Normal", 'build-jellythemes') => 'tmb-standar',
	                        esc_html__("Rounded", 'build-jellythemes') => 'tmb-rounded',
	                      ),
    		),
	   		array(
		            "type" => "attach_image",
		            "heading" => esc_html__("Member photo", "jellythemes"),
		            "param_name" => "image",
		            "value" => "",
		            "description" => esc_html__("Select image from media library.", "jellythemes")
		        ),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Member name", 'build-jellythemes'),
				"param_name" => "name",
				"value" => esc_html__("John Doe", 'build-jellythemes'),
				"description" => esc_html__("Enter the member name.", 'build-jellythemes')
			),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Member position", 'build-jellythemes'),
				"param_name" => "position",
				"value" => esc_html__("CEO", 'build-jellythemes'),
				"description" => esc_html__("Enter the member position.", 'build-jellythemes')
			),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Member twitter url", 'build-jellythemes'),
				'description' => esc_html__('Leave blank to hide social icon','build-jellythemes'),
				"param_name" => "tw_url",
				"value" => '',
			),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Member facebook url", 'build-jellythemes'),
				'description' => esc_html__('Leave blank to hide social icon','build-jellythemes'),
				"param_name" => "fb_url",
				"value" => '',
			),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Member google+ url", 'build-jellythemes'),
				'description' => esc_html__('Leave blank to hide social icon','build-jellythemes'),
				"param_name" => "gp_url",
				"value" => '',
			),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Member pinterest url", 'build-jellythemes'),
				'description' => esc_html__('Leave blank to hide social icon','build-jellythemes'),
				"param_name" => "pi_url",
				"value" => '',
			),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Member instagram url", 'build-jellythemes'),
				'description' => esc_html__('Leave blank to hide social icon','build-jellythemes'),
				"param_name" => "ig_url",
				"value" => '',
			),
	   )
	));

?>