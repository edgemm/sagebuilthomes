<?php
/***********************************************************
*
*	VERTICAL OFFSET BLOCK
*
***********************************************************/

function build_jellythemes_voffset( $atts, $content = null ) {
	extract( shortcode_atts( array(
        'height' => '',
	), $atts ) );
   return '<div class="voffset' . esc_attr($height) . '"></div>';
}
add_shortcode( 'build_jellythemes_voffset', 'build_jellythemes_voffset' );

if (function_exists('vc_map')) {
	vc_map( array(
	   "name" => esc_html__("Vertical spacer", 'build-jellythemes'),
	   "base" => "build_jellythemes_voffset",
	   "class" => "",
	   "icon" => "jelly-icon",
	   "category" => esc_html__('Jellythemes', 'build-jellythemes'),
	   "params" => array(
	      array(
		      "type" => "dropdown",
		      "heading" => esc_html__('Offset height', 'build-jellythemes'),
		      "param_name" => "height",
		      "value" => array(
						esc_html__("10px", 'build-jellythemes') => '10',
						esc_html__("20px", 'build-jellythemes') => '20',
						esc_html__("30px", 'build-jellythemes') => '30',
						esc_html__("40px", 'build-jellythemes') => '40',
						esc_html__("50px", 'build-jellythemes') => '50',
						esc_html__("60px", 'build-jellythemes') => '60',
						esc_html__("70px", 'build-jellythemes') => '70',
						esc_html__("80px", 'build-jellythemes') => '80',
						esc_html__("90px", 'build-jellythemes') => '90',
						esc_html__("100px", 'build-jellythemes') => '100',
						esc_html__("150px", 'build-jellythemes') => '150',
						esc_html__("200px", 'build-jellythemes') => '200',
						),
		      "description" => esc_html__("Height will be adjust on responsive", 'build-jellythemes')
		    )
	   )
	));
}