<?php
/***********************************************************
*
*	PORTFOLIO WITH FILTER
*
***********************************************************/

add_shortcode( 'build_jellythemes_works', 'build_jellythemes_works_list' );
function build_jellythemes_works_list($atts, $content=null) {
    extract( shortcode_atts( array(
        'limit' => 8,
        'columns' => 'col-sm-4'
        ), $atts ) );

    $return  = '
        <ul class="filter text-center">
                      <li class="filter-item"><a class="active filter-link" href="#filter" data-filter="*">' . esc_html__('All Works', 'build-jellythemes') .'</a></li>';

    $types = get_terms('type', array('hide_empty'=>0));

    if ( $types && ! is_wp_error( $types ) ) :
        foreach ( $types as $type ) {
        	$return .= '<li class="filter-item"><a href="#filter" class="filter-link" data-filter=".'. esc_js($type->slug)  . '">' . $type->name . '</a></li>';
        }
    endif;
    $return .= '</ul>
            	<div class="folio-grid clearfix voffset100">';
                $projects = new WP_Query(array('post_type'=>'works', 'posts_per_page' => esc_attr($limit)));
                while ($projects->have_posts()) : $projects->the_post();
                    $term_list = wp_get_post_terms(get_the_ID(), 'type', array("fields" => "names"));
                    $return .= '<article class="folio-item ' . implode(' ', get_post_class('element')) . ' ' . esc_attr($columns)  . '">
			                        <a href="' . get_permalink() .'" class="folio-link">
			                            ' .  wp_get_attachment_image( get_post_thumbnail_id(get_the_ID()), 'build_jellythemes_project_thumb', false, array('class' => 'img-responsive')).'
			                            <div class="folio-over">
			                                <div class="folio-inner">
			                                    <div class="folio-data">
			                                        <h4 class="folio-name">' . get_the_title() . '</h4>
			                                        <h5 class="folio-type">' . rtrim(implode(',', $term_list), ',') . '</h5>
			                                        <div class="icons">
			                                            <i class="icon fa fa-search"></i>
			                                            <i class="icon fa fa-plus"></i>
			                                        </div>
			                                    </div>
			                                </div>
			                            </div>
			                        </a>
			                    </article>';
                endwhile;
    $return .=  '</div>';
    return $return;
}

if (function_exists('vc_map')) {
	vc_map( array(
		"name" => esc_html__("Portfolio", 'build-jellythemes'),
		"description" => esc_html__("Portfolio with filter", 'build-jellythemes'),
		"base" => "build_jellythemes_works",
		"class" => "",
		"icon" => "jelly-icon",
		"category" => esc_html__('Jellythemes', 'build-jellythemes'),
		"params" => array(
			array(
				"type" => "dropdown",
				"heading" => esc_html__('Number of works to show', 'build-jellythemes'),
				"param_name" => "limit",
				"value" => array(
							esc_html__("Unlimited", 'build-jellythemes') => '-1',
							esc_html__("1", 'build-jellythemes') => '1',
							esc_html__('2', 'build-jellythemes') => '2',
							esc_html__('3', 'build-jellythemes') => '3',
							esc_html__('3', 'build-jellythemes') => '3',
							esc_html__('4', 'build-jellythemes') => '4',
							esc_html__('5', 'build-jellythemes') => '5',
							esc_html__("6", 'build-jellythemes') => '6',
							esc_html__('7', 'build-jellythemes') => '7',
							esc_html__('8', 'build-jellythemes') => '8',
							esc_html__('9', 'build-jellythemes') => '9',
							esc_html__('10', 'build-jellythemes') => '10',
							esc_html__('11', 'build-jellythemes') => '11',
							esc_html__('12', 'build-jellythemes') => '12',
							),
				"description" => esc_html__("Select the number of works you want to show", "jellythemes"),
			),
			array(
				"type" => "dropdown",
				"heading" => esc_html__('Portfolio Layout', 'build-jellythemes'),
				"param_name" => "columns",
				"value" => array(
							esc_html__("3 columns", 'build-jellythemes') => 'col-sm-4',
							esc_html__("2 columns", 'build-jellythemes') => 'col-sm-6',
							esc_html__('4 columns', 'build-jellythemes') => 'col-sm-3',
							),
				"std" => 'col-sm-4',
			)
		)
	));
}

?>