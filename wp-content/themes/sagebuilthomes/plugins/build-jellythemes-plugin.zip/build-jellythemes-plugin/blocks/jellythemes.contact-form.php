<?php
/***********************************************************
*
* CONTACT FORM BLOCK
*
***********************************************************/

function build_jellythemes_contact_form( $atts, $content = null ) {
	$jellythemes = build_jellythemes_theme_options();
    return '<form id="contactform" action="' . plugins_url( 'mail.php', dirname(__FILE__) ) . '" method="post">
                    <div class="row text-center contact-form">
                        <div class="jt_col col-md-4">
                            <input id="name" name="name" type="text" class="required form-control" placeholder="' . esc_html__('Name', 'build-jellythemes') . '">
                        </div>
                        <div class="jt_col col-md-4">
                            <input id="email" name="email" type="text" class="required form-control" placeholder="' . esc_html__('Email', 'build-jellythemes') . '">
                        </div>
                        <div class="jt_col col-md-4">
                            <input id="phone" name="phone" type="text" class="form-control" placeholder="' . esc_html__('Phone', 'build-jellythemes') . '">
                        </div>
                        <div class="jt_col col-md-12">
                            <textarea id="message" name="message" class="required form-control" placeholder="' . esc_html__('Message', 'build-jellythemes') . '"></textarea>
                        </div>
                        <div class="jt_col col-md-4 col-md-offset-4"><button type="submit" class="button fill">' . esc_html__('Submit', 'build-jellythemes') . '</button></div>
                        <div class="jt_col col-md-4 col-md-offset-4">
                            <div class="formSent success primary">' . esc_html__('Your Message Has Been Sent! Thank you for contacting us.', 'build-jellythemes') . '</div>
                        </div>
                    </div>
                </form>';
}
add_shortcode( 'build_jellythemes_contact_form', 'build_jellythemes_contact_form' );

if (function_exists('vc_map')) {
    vc_map( array(
        "name" => esc_html__("Contact form", 'build-jellythemes'),
        "base" => "build_jellythemes_contact_form",
        "class" => "",
        "icon" => "jelly-icon",
        "category" => esc_html__('Jellythemes', 'build-jellythemes'),
        "description" => esc_html__('Contact form', 'build-jellythemes'),
        "show_settings_on_create" => false,
        "params" => array()
    ));
}