<?php
/***********************************************************
*
*	BASIC CONTENT BLOCK
*
***********************************************************/

function build_jellythemes_content( $atts, $content = null ) {
	extract( shortcode_atts( array(
        'type' => 'text-content',
	), $atts ) );
	$content = wpb_js_remove_wpautop($content, true);
   	return '<div class="' . esc_attr($type) . '">' . wpautop($content) . '</div>';
}
add_shortcode( 'build_jellythemes_content', 'build_jellythemes_content' );

if (function_exists('vc_map')) {
	vc_map( array(
	   "name" => esc_html__("Section content", 'build-jellythemes'),
	   "base" => "build_jellythemes_content",
	   "class" => "",
	   "icon" => "jelly-icon",
	   "category" => esc_html__('Jellythemes', 'build-jellythemes'),
	   "params" => array(
	      array(
	         "type" => "textarea_html",
	         "holder" => "div",
	         "class" => "",
	         "heading" => esc_html__("Content", 'build-jellythemes'),
	         "param_name" => "content",
	         "value" => esc_html__("<p>I am test text block. Click edit button to change this text.</p>", 'build-jellythemes'),
	         "description" => esc_html__("Enter your content.", 'build-jellythemes')
	      ),
	      array(
		      "type" => "dropdown",
		      "heading" => esc_html__('Type', 'build-jellythemes'),
		      "param_name" => "type",
		      "value" => array(
	                    esc_html__("Post content", 'build-jellythemes') => 'text-content',
	                  ),
		    )
	   )
	));
}

?>