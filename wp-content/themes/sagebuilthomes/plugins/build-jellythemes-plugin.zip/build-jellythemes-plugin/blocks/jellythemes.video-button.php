<?php
/***********************************************************
*
*	VIDEO BUTTON
*
***********************************************************/

function build_jellythemes_video_button( $atts, $content = null ) {
	extract( shortcode_atts( array(
        'link' => ''
	), $atts ) );
	return '<a href="#" class="play" data-toggle="modal" data-target="#video-modal"><i class="icon fa fa-play"></i></a>

		<div class="modal fade" id="video-modal">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-body">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        ' . wp_oembed_get($link) . '
                    </div>
                </div>
            </div>
        </div>

	';
}
add_shortcode( 'build_jellythemes_video_button', 'build_jellythemes_video_button' );

if (function_exists('vc_map')) {
	vc_map( array(
	   "name" => esc_html__("Video button", 'build-jellythemes'),
	   "base" => "build_jellythemes_video_button",
	   "class" => "",
	   "icon" => "jelly-icon",
	   "category" => esc_html__('Jellythemes', 'build-jellythemes'),
	   "params" => array(
	      array(
	         "type" => "textfield",
	         "holder" => "div",
	         "class" => "",
	         "heading" => esc_html__("Video URL", 'build-jellythemes'),
	         "param_name" => "link",
	         "value" => esc_html__("#", 'build-jellythemes'),
	         "description" => esc_html__("Youtube or vimeo URL", 'build-jellythemes')
	      ),
	      
	   )
	));
}
