<?php
/***********************************************************
*
*	FEATURES/SERVICES BLOCK
*
***********************************************************/

function build_jellythemes_service( $atts, $content = null ) {
	extract( shortcode_atts( array(
        'image' => '',
        'title' => 'Service name',
        'button_link' => site_url()
	), $atts ) );
	return '<div class="wwd-block">
                    <a href="' . esc_url($button_link) . '">' . wp_get_attachment_image($image, 'full')  .  '</a>
                    <div class="wwd-data">
                        <h3 class="wwd-title">' . esc_html($title) . '</h3>
                        <a href="' . esc_url($button_link) . '" class="wwd-link">'. esc_html__('Read More', 'build-jellythemes') . '</a>
                    </div>
                </div>';
}
add_shortcode( 'build_jellythemes_service', 'build_jellythemes_service' );

if (function_exists('vc_map')) {
	vc_map( array(
	   "name" => esc_html__("Service block (with image)", 'build-jellythemes'),
	   "base" => "build_jellythemes_service",
	   "class" => "",
	   "icon" => "jelly-icon",
	   "category" => esc_html__('Jellythemes', 'build-jellythemes'),
	   "params" => array(
	   		array(
	            "type" => "attach_image",
	            "heading" => esc_html__("Service image", "jellythemes"),
	            "param_name" => "image",
	            "value" => "",
	            "description" => esc_html__("Select image from media library.", "jellythemes")
	        ),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Service title", 'build-jellythemes'),
				"param_name" => "title",
				"value" => esc_html__("Service name", 'build-jellythemes'),
				"description" => esc_html__("Enter your service title.", 'build-jellythemes')
			),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Read more link", 'build-jellythemes'),
				"param_name" => "button_link",
				"value" => site_url(),
			),
	   )
	));
}

/***********************************************************
*
*	SERVICES BLOCK (WITH ICON)
*
***********************************************************/

function build_jellythemes_service_icon( $atts, $content = null ) {
	extract( shortcode_atts( array(
        'icon' => 'icon-big-mansion',
        'title' => 'Service name',
        'button_link' => site_url(),
        'text_content' => "Sed diam nonumy eirmod roedtem por in vid unt ut labore magnaadi piocar semper laoreet"
	), $atts ) );
    return '<div class="service text-center">
                    <div class="icon fz32"><i class="' . esc_attr($icon) . '"></i></div>
                    <h2 class="title fz20">' . esc_html($title) . '</h2>
                    <h3 class="subtitle">' . esc_html($text_content) . '</h3>
                    <a class="more" href="' . esc_url($button_link) . '"><i class="icon fa fa-arrow-right"></i></a>
                </div>';
}
add_shortcode( 'build_jellythemes_service_icon', 'build_jellythemes_service_icon' );

if (function_exists('vc_map')) {
	global $build_jellythemes_fonticons;
	vc_map( array(
	   "name" => esc_html__("Service block (with icon)", 'build-jellythemes'),
	   "base" => "build_jellythemes_service_icon",
	   "class" => "",
	   "icon" => "jelly-icon",
	   "category" => esc_html__('Jellythemes', 'build-jellythemes'),
	   "params" => array(
	   		array(
				"type" => "dropdown",
				"heading" => esc_html__('Icon', 'build-jellythemes'),
				"param_name" => "icon",
				"value" => $build_jellythemes_fonticons,
			),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Service title", 'build-jellythemes'),
				"param_name" => "title",
				"value" => esc_html__("Service name", 'build-jellythemes'),
				"description" => esc_html__("Enter your service title.", 'build-jellythemes')
			),
			array(
				"type" => "textarea",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Text content", 'build-jellythemes'),
				"param_name" => "text_content",
				"value" => esc_html__("Sed diam nonumy eirmod roedtem por in vid unt ut labore magnaadi piocar semper laoreet", 'build-jellythemes'),
			),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Link", 'build-jellythemes'),
				"param_name" => "button_link",
				"value" => site_url(),
			),
	   )
	));
}

?>