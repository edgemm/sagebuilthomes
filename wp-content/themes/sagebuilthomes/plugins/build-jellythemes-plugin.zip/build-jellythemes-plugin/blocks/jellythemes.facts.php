<?php
/***********************************************************
*
*	SOCIAL COUNTER
*
***********************************************************/

function build_jellythemes_social_counter( $atts, $content = null ) {
	extract( shortcode_atts( array(
        'icon' => 'fa fa-facebook',
        'counter' => '2145',
        'color' => '',
        'link' => ''
	), $atts ) );
	return '<div class="social-counter clearfix" style="background-color:' . esc_attr($color) . ';">
                <i class="social-icon icon ' . esc_attr($icon) . '"></i>
                <div class="number">
                    ' . esc_attr($counter) . '
                    <a href="' . esc_url($link) . '">' . esc_html__('follow', 'build-jellythemes') . ' <i class="icon fa fa-plus"></i></a>
                </div>
            </div>';
}
add_shortcode( 'build_jellythemes_social_counter', 'build_jellythemes_social_counter' );

if (function_exists('vc_map')) {
	global $build_jellythemes_fonticons;
	vc_map( array(
	   "name" => esc_html__("Social Link", 'build-jellythemes'),
	   "base" => "build_jellythemes_social_counter",
	   "class" => "",
	   "icon" => "jelly-icon",
	   "category" => esc_html__('Jellythemes', 'build-jellythemes'),
	   "params" => array(
	   		array(
				"type" => "dropdown",
				"heading" => esc_html__('Icon', 'build-jellythemes'),
				"param_name" => "icon",
				"value" => $build_jellythemes_fonticons,
			),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Counter number", 'build-jellythemes'),
				"param_name" => "counter",
				"value" => esc_html__("2154", 'build-jellythemes'),
				"description" => esc_html__("Integer number", 'build-jellythemes')
			),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Link", 'build-jellythemes'),
				"param_name" => "link",
				"value" => site_url(),
			),
			array(
				"type" => "colorpicker",
				"heading" => esc_html__("Background color", 'build-jellythemes'),
				"param_name" => "color"
			),
	   )
	));
}


?>