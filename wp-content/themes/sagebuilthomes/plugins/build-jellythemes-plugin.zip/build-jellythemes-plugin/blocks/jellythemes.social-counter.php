<?php
/***********************************************************
*
*	FACTS BLOCK
*
***********************************************************/

function build_jellythemes_fact_item( $atts, $content = null ) {
	extract( shortcode_atts( array(
        'icon' => 'fa fa-heart-o',
        'counter' => '2145',
        'fact' => 'Awards won',
	), $atts ) );
	return '<div class="counter clearfix" data-count="' . esc_attr($counter) . '">
                    <i class="icon ' . esc_attr($icon) . '"></i>
                    <div class="data">
                        <span class="number">' . esc_attr($counter) . '</span>
                        <span class="literal">' . esc_attr($fact) . '</span>
                    </div>
                </div>';
}
add_shortcode( 'build_jellythemes_fact_item', 'build_jellythemes_fact_item' );

if (function_exists('vc_map')) {
	global $build_jellythemes_fonticons;
	vc_map( array(
	   "name" => esc_html__("Counter", 'build-jellythemes'),
	   "base" => "build_jellythemes_fact_item",
	   "class" => "",
	   "icon" => "jelly-icon",
	   "category" => esc_html__('Jellythemes', 'build-jellythemes'),
	   "params" => array(
	   		array(
				"type" => "dropdown",
				"heading" => esc_html__('Icon', 'build-jellythemes'),
				"param_name" => "icon",
				"value" => $build_jellythemes_fonticons,
			),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Counter number", 'build-jellythemes'),
				"param_name" => "counter",
				"value" => esc_html__("2154", 'build-jellythemes'),
				"description" => esc_html__("Integer number", 'build-jellythemes')
			),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Fact", 'build-jellythemes'),
				"param_name" => "fact",
				"value" => esc_html__("Awards won", 'build-jellythemes'),
			),
	   )
	));
}


?>