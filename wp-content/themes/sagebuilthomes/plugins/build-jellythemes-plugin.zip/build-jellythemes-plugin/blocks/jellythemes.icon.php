<?php
/***********************************************************
*
*	FONT AWESOME ICON
*
***********************************************************/

function build_jellythemes_icon( $atts, $content = null ) {
	extract( shortcode_atts( array(
        'icon' => 'fa-heart-o',
        'color' => 'dark',
        'size' => '30',
	), $atts ) );
	$size = 'fz' . $size;
	return '<div class="icon ' . esc_attr($color) . ' ' . esc_attr($size) . '"><i class="' . esc_attr($icon) . '"></i></div>';
}
add_shortcode( 'build_jellythemes_icon', 'build_jellythemes_icon' );
global $build_jellythemes_fonticons;
global $build_jellythemes_fontsizes;
if (function_exists('vc_map')) {
	vc_map( array(
	   "name" => esc_html__("Icon", 'build-jellythemes'),
	   "base" => "build_jellythemes_icon",
	   "class" => "",
	   "icon" => "jelly-icon",
	   "category" => esc_html__('Jellythemes', 'build-jellythemes'),
	   "params" => array(
			array(
				"type" => "dropdown",
				"heading" => esc_html__('Icon', 'build-jellythemes'),
				"param_name" => "icon",
				"value" => $build_jellythemes_fonticons,
			),
			array(
				"type" => "dropdown",
				"heading" => esc_html__('Color', 'build-jellythemes'),
				"param_name" => "color",
				"value" => array('Dark' => 'dark', 'Light' => 'light', 'Primary color' => 'primary'),
			),
			array(
				"type" => "dropdown",
				"heading" => esc_html__('Size in pixels', 'build-jellythemes'),
				"param_name" => "size",
				"value" => $build_jellythemes_fontsizes,
			)
	   )
	));
}

?>