<?php
/***********************************************************
*
*	BUTTON
*
***********************************************************/

function build_jellythemes_button( $atts, $content = null ) {
	extract( shortcode_atts( array(
        'type' => '',
        'link' => '',
        'button_text' => 'Button text'
	), $atts ) );
   return '<a href="' . esc_url($link) . '" class="button ' . esc_attr($type) . '">' . esc_html($button_text) . '</a>';
}
add_shortcode( 'build_jellythemes_button', 'build_jellythemes_button' );

if (function_exists('vc_map')) {
	vc_map( array(
	   "name" => esc_html__("Button", 'build-jellythemes'),
	   "base" => "build_jellythemes_button",
	   "class" => "",
	   "icon" => "jelly-icon",
	   "category" => esc_html__('Jellythemes', 'build-jellythemes'),
	   "params" => array(
	      array(
	         "type" => "textfield",
	         "holder" => "div",
	         "class" => "",
	         "heading" => esc_html__("Button text", 'build-jellythemes'),
	         "param_name" => "button_text",
	         "value" => esc_html__("Button text", 'build-jellythemes'),
	      ),
	      array(
	         "type" => "textfield",
	         "holder" => "div",
	         "class" => "",
	         "heading" => esc_html__("Link", 'build-jellythemes'),
	         "param_name" => "link",
	         "value" => esc_html__("#", 'build-jellythemes'),
	         "description" => esc_html__("URL to link", 'build-jellythemes')
	      ),
	      array(
		      "type" => "dropdown",
		      "heading" => esc_html__('Type', 'build-jellythemes'),
		      "param_name" => "type",
		      "value" => array(
	                    esc_html__("Normal", 'build-jellythemes') => '',
	                    esc_html__("Fill", 'build-jellythemes') => 'fill',
	                    esc_html__("Dark", 'build-jellythemes') => 'dark',
	                    esc_html__("Light", 'build-jellythemes') => 'light',
	                  ),
		    )
	   )
	));
}
