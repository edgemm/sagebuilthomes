<?php
/***********************************************************
*
*   ClIENTS LOGOS CAROUSEL
*
***********************************************************/

function build_jellythemes_logos_carousel( $atts, $content = null ) {
	extract( shortcode_atts( array(
        'image' => '',
        'link' => site_url(),
	), $atts ) );
	
    return '<div class="client-logo"><a target="_blank" href="' . esc_url($link) . '">' . wp_get_attachment_image($image, 'full')  .  '</a></div>';

}
add_shortcode( 'build_jellythemes_logos_carousel', 'build_jellythemes_logos_carousel' );

if (function_exists('vc_map')) {
    vc_map( array(
        "name" => esc_html__("Client Logo", "jellythemes"),
        "base" => "build_jellythemes_logos_carousel",
        "icon" => "icon-wpb-images-carousel",
        "category" => esc_html__('Jellythemes', 'build-jellythemes'),
        "description" => esc_html__('Client logo, showed 5 in a row', 'build-jellythemes'),
        "params" => array(
                array(
                    "type" => "attach_image",
                    "heading" => esc_html__("Logo", "jellythemes"),
                    "param_name" => "image",
                    "description" => esc_html__("Select image from media library.", "jellythemes")
                ),
                array(
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => esc_html__("Link", 'build-jellythemes'),
                    "param_name" => "link",
                    "value" => site_url(),
                ),
            )
    ) );
}