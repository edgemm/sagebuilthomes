<?php
/***********************************************************
*
*	TESTIMONIALS BLOCK
*
***********************************************************/

function build_jellythemes_testimonials_list($atts, $content=null) {
    extract( shortcode_atts( array(
        'limit' => 5
        ), $atts ) );
    global $post;
    $back=$post; //Backup post data
    $return = '<div class="testimonials carousel-wrapper with_buttons">
                        <div class="testimonials-carousel owl-carousel generic-carousel">';
	$testimonials = new WP_Query(array('post_type'=>'testimonials', 'posts_per_page' => esc_attr($limit)));
    while ($testimonials->have_posts()) : $testimonials->the_post();
        $image = get_post_meta( $post->ID, '_build_jellythemes_author_avatar', true );
        $return .= '<div class="item">
                        <p>' . strip_tags(get_post_meta( $post->ID, '_build_jellythemes_testimonial', true )). '</p>
                        <span class="author">' . get_post_meta( $post->ID, '_build_jellythemes_author_name', true ). '</span>
                    </div>';
    endwhile;
    $post=$back; //restore post object
	$return .=  '</div>
            </div>';
    return $return;
}

add_shortcode( 'build_jellythemes_testimonials', 'build_jellythemes_testimonials_list' );

if (function_exists('vc_map')) {
	vc_map( array(
	   "name" => esc_html__("Testimonials", 'build-jellythemes'),
	   "description" => esc_html__("Testimonials carousel", 'build-jellythemes'),
	   "base" => "build_jellythemes_testimonials",
	   "class" => "",
	   "icon" => "jelly-icon",
	   "category" => esc_html__('Jellythemes', 'build-jellythemes'),
	   "params" => array(
	      array(
		      "type" => "dropdown",
		      "heading" => esc_html__('Number of services to show', 'build-jellythemes'),
		      "param_name" => "limit",
		      "value" => array(
		                        esc_html__("Unlimited", 'build-jellythemes') => '-1',
		                        esc_html__("1", 'build-jellythemes') => '1',
		                        esc_html__('2', 'build-jellythemes') => '2',
		                        esc_html__('3', 'build-jellythemes') => '3',
								esc_html__('3', 'build-jellythemes') => '3',
								esc_html__('4', 'build-jellythemes') => '4',
								esc_html__('5', 'build-jellythemes') => '5',
								esc_html__("6", 'build-jellythemes') => '6',
		                        esc_html__('7', 'build-jellythemes') => '7',
		                        esc_html__('8', 'build-jellythemes') => '8',
								esc_html__('9', 'build-jellythemes') => '9',
								esc_html__('10', 'build-jellythemes') => '10',
								esc_html__('11', 'build-jellythemes') => '11',
								esc_html__('12', 'build-jellythemes') => '12',
		                      ),
		      "description" => esc_html__("Select the number of services you want to show", "jellythemes"),
		    )
	   )
	));
}

?>