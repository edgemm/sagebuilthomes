<?php
/***********************************************************
*
*	LATEST BLOG POSTS BLOCK
*
***********************************************************/

add_shortcode( 'build_jellythemes_posts', 'build_jellythemes_posts_list' );
function build_jellythemes_posts_list($atts, $content=null) {
    extract( shortcode_atts( array('limit' => 3), $atts ) );
    $blog = new WP_Query(array('post_type'=>'post', 'ignore_sticky_posts' => 1,'posts_per_page' => esc_attr($limit)));
    $return = '';
    while ($blog->have_posts()) : $blog->the_post();
        $return .= '<div class="col-md-4 clearfix">
                        <div class="time">
                          <span class="date">' . get_the_time('d') . '</span>
                          <span class="month">' . get_the_time('F') . '</span>
                          <span class="year">' . get_the_time('Y') . '</span>
                        </div>
                        <div class="content">
						   <div class="blog-thumb">
						        <a href="'. get_permalink() .'">
						        	' .  wp_get_attachment_image( get_post_thumbnail_id(get_the_ID()), 'build_jellythemes_blog_thumb', false, array('class' => 'blog-image-tiny')).'
						            <div class="blog-dark-overlay"></div>
						            <div class="blog-inner">
						                <div class="blog-inner-ctr">
						                    <span class="zoom"></span>
						                    <h4>' . esc_html__('Read more', 'build-jellythemes') . '</h4>
						                </div>
						            </div>
						        </a>
						  </div>
						  <h2 class="post-title">' . get_the_title() . '</h2>
						  <p>' . get_the_excerpt() . '</p>
						  <a href="'. get_permalink() .'" class="btn btn--alt">' . esc_html__('Continue', 'build-jellythemes') . '</a>
                        </div>
                    </div>';
    endwhile;
    return $return;
}

if (function_exists('vc_map')) {
	vc_map( array(
		"name" => esc_html__("Blog posts", 'build-jellythemes'),
		"description" => esc_html__("Show latest blog posts", 'build-jellythemes'),
		"base" => "build_jellythemes_posts",
		"class" => "",
		"icon" => "jelly-icon",
		"category" => esc_html__('Jellythemes', 'build-jellythemes'),
		"params" => array(
			array(
				"type" => "dropdown",
				"heading" => esc_html__('Number of posts to show', 'build-jellythemes'),
				"param_name" => "limit",
				"value" => array(
							esc_html__('3', 'build-jellythemes') => '3',
							esc_html__("6", 'build-jellythemes') => '6',
							esc_html__('9', 'build-jellythemes') => '9',
							esc_html__('12', 'build-jellythemes') => '12',
							),
				"description" => esc_html__("Select the number of posts you want to show", "jellythemes"),
			)
		)
	));
}

?>