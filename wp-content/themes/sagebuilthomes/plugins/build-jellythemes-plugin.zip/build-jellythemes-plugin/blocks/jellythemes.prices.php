<?php
/***********************************************************
*
*	PRICING TABLES BLOCK
*
***********************************************************/

function build_jellythemes_features_item( $atts, $content = null ) {
    return '<li>' . esc_attr(wp_strip_all_tags($content)) . '</li>';
}
add_shortcode( 'build_jellythemes_features_item', 'build_jellythemes_features_item' );

function build_jellythemes_price_table( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'heading' => 'Professional',
        'price' => '<span>$</span>34<sup>.99</sup>',
        'period' => 'Monthly',
        'button_link' => '#',
        'button_text' => 'Sign up',
	), $atts ) );
    return '<div class="pricing__table">
                <div class="heading">' . esc_attr($heading) . '</div>
                <div class="price">' . wp_kses($price, array('sup' => array(), 'span' => array())) . '</div>
                <div class="month">' . esc_attr($period) . '</div>
                <ul>
                    '. do_shortcode($content) .'
                </ul>
                <a class="btn" href="' . esc_url($button_link) . '">' . esc_attr($button_text) . '</a>
            </div>';
}
add_shortcode( 'build_jellythemes_price_table', 'build_jellythemes_price_table' );


if (function_exists('vc_map')) {
	vc_map( array(
	    "name" => esc_html__("Pricing table", "jellythemes"),
	    "base" => "build_jellythemes_price_table",
	    "as_parent" => array('only' => 'build_jellythemes_features_item'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
	    "content_element" => true,
	   	"category" => esc_html__('Jellythemes', 'build-jellythemes'),
	    "show_settings_on_create" => true,
	    "params" => array(
	        array(
	            "type" => "textfield",
	            "heading" => esc_html__("Table heading", "jellythemes"),
	            "param_name" => "heading",
	            "value" => esc_html__("Professional", 'build-jellythemes'),
	        ),
	        array(
	            "type" => "textfield",
	            "heading" => esc_html__("Price", "jellythemes"),
	            "param_name" => "price",
	            "value" => esc_html__("<span>$</span>34<sup>.99</sup>", 'build-jellythemes'),
	        ),
	        array(
	            "type" => "textfield",
	            "heading" => esc_html__("Period", "jellythemes"),
	            "param_name" => "period",
	            "value" => esc_html__("Monthly", 'build-jellythemes'),
	        ),
	        array(
	            "type" => "textfield",
	            "heading" => esc_html__("Button link", "jellythemes"),
	            "param_name" => "button_link",
	            "value" => esc_html__("#", 'build-jellythemes'),
	        ),
	        array(
	            "type" => "textfield",
	            "heading" => esc_html__("Button text", "jellythemes"),
	            "param_name" => "button_text",
	            "value" => esc_html__("Sign up", 'build-jellythemes'),
	        ),
	    ),
	    "js_view" => 'VcColumnView'
	) );
	vc_map( array(
	   "name" => esc_html__("Feature item", 'build-jellythemes'),
	   "base" => "build_jellythemes_features_item",
	   "class" => "",
	   "icon" => "jelly-icon",
	   "category" => esc_html__('Jellythemes', 'build-jellythemes'),
	   "as_child" => array('only' => 'build_jellythemes_price_table'),
	   "params" => array(
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Feature item", 'build-jellythemes'),
				"param_name" => "content",
				"value" => esc_html__("Fully Integrated E-Commerce", 'build-jellythemes'),
				"description" => esc_html__("Feature item list", 'build-jellythemes')
			),
	   )
	));
}

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_build_jellythemes_Price_Table extends WPBakeryShortCodesContainer {
    }
    class WPBakeryShortCode_build_jellythemes_Features_Item extends WPBakeryShortCode {
    }
}

?>