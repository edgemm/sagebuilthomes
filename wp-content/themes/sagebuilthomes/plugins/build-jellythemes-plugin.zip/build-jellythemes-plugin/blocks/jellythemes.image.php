<?php
/***********************************************************
*
*	SINGLE IMAGE BLOCK
*
***********************************************************/

function build_jellythemes_image( $atts, $content = null ) {
	extract( shortcode_atts( array(
        'image' => '', 
        'class' => '',
	), $atts ) );
	$return = 	wp_get_attachment_image($image, 'full', false, array('class' => esc_attr($class)));
    return $return;
}
add_shortcode( 'build_jellythemes_image', 'build_jellythemes_image' );


if (function_exists('vc_map')) {
	vc_map( array(
	    "name" => esc_html__("Single Image", "jellythemes"),
	    "base" => "build_jellythemes_image",
	    "icon" => "jelly-icon",
	    "category" => esc_html__('Jellythemes', 'build-jellythemes'),
	    "description" => esc_html__('Insert singles image (full size)', 'build-jellythemes'),
	    "params" => array(
		        array(
		            "type" => "attach_image",
		            "heading" => esc_html__("Image", "jellythemes"),
		            "param_name" => "image",
		            "value" => "",
		            "description" => esc_html__("Select image from media library. Shows full size", "jellythemes")
		        ),
		        array(
			         "type" => "textfield",
			         "holder" => "div",
			         "class" => "",
			         "heading" => esc_html__("Class name", 'build-jellythemes'),
			         "param_name" => "class",
			         "description" => esc_html__("Add CSS classes separated by spaces", 'build-jellythemes')
			      ),
		    )
	) );
}