
<?php 
	$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
	require_once( $parse_uri[0] . 'wp-load.php' );
	$jellythemes = build_jellythemes_theme_options(); 
?>
<?php
if(isset($_POST['email'])){
		$mailTo = get_option('admin_email');
		$subject = "Mail From: " . $jellythemes['blogname'];
		$body = "New message from web: " . $jellythemes['blogname'] . "
<br><br>
FROM: ".$_POST['email']."<br>
NAME: ".$_POST['name']."<br>
PHONE: ".$_POST['phone']."<br>
COMMENTS: ".$_POST['message']."<br>";
		$headers = "To: Solido <".$mailTo.">\r\n";
		$headers .= "Content-Type: text/html";
		//envio destinatario
		$mail_success =  wp_mail($mailTo, utf8_decode($subject), utf8_decode($body), $headers);
}
?>